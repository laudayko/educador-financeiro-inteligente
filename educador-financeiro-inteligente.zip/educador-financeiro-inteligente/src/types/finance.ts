export type FinancialData = {
  name: string
  income: number
  fixedExpenses: number
  variableExpenses: number
  goal: string
  goalAmount: number
}

export type FinancialResult = {
  id: string
  createdAt: string
  data: FinancialData
  balance: number
  savingsRate: number
  status: 'positivo' | 'atenção' | 'crítico'
  insights: string[]
}
